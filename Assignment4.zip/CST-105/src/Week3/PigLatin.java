//  Ray Kecham
//  CST-105
//  September 28 2017
//  Charles Lively
package Week3;
import java.io.File;
import java.util.Scanner;
public class PigLatin {
    public static void main(String[] args) throws Exception {
        String word;
        String newWord;
        String filePath = "C:\\temp\\test.txt";
        File file = new File (filePath);

        Scanner stdIn = new Scanner(file); {
            
            word=stdIn.nextLine();
            newWord=stdIn.nextLine();
        
            if
                    (
                    word.charAt(0)=='a' ||
                    word.charAt(0)=='A' || 
                    word.charAt(0)=='e' || 
                    word.charAt(0)=='E' || 
                    word.charAt(0)=='i' || 
                    word.charAt(0)=='I' || 
                    word.charAt(0)=='o' || 
                    word.charAt(0)=='O' || 
                    word.charAt(0)=='u' || 
                    word.charAt(0)=='U') {
                        newWord= word + "way"; 
            }
            else 
                {
            newWord=word.substring(1) + word.charAt(0) + "ay";
                    }     
            System.out.format(" " + word + " " + "%S", newWord + " ");
        }
    }
}

