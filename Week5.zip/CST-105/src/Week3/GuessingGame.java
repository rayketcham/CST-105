//  Ray Kecham
//  CST-105
//  September 28 2017
//  Charles Lively
package Week3;
import java.util.Scanner;
public class GuessingGame {
    public static void main(String []args) {
        int number = (int)(Math.random() * 10);
        
        Scanner input = new Scanner(System.in);
            System.out.println("Pick a number between 0 and 10000");
        int attempts = 0;
        while (true) {
            System.out.print("Enter your number: ");

        int guess = input.nextInt();
        attempts += 1;
        if (guess == number){
            System.out.println("Correct, the number was \u001B[42m"  + number);
            System.out.println("It took " + attempts +" attempts to get the right number!");
            System.exit(0);
        }
        else if (guess > number) {
            System.out.println("Too high,\033[31m " + guess + "\033[0m is wrong, try again!");
        }
        else {
            System.out.println("Too low,\033[31m " + guess + "\033[0m is wrong, try again!");    
            }
        }
    }
}