package Week1;

//Written by: Ray Ketcham
//Last Modified: 9/11/174

//Class: CST-105
//Instructor:  DR. Charles Lively
public class Welcome {
    public static void main (String args[]) {
        System.out.println("\033[31;1mMy Name = \033[32;1;2m Ray Ketcham");
        System.out.println("\033[36mMy Favorite Color =\033[33m Yellow\033[34m and Blue");
        System.out.println("If I won the lottery, I would pay someone to teach me to code this exclusively one on one!");
                }
}