package Week1;

import java.util.Scanner; // Scanner is in the java.util package
    public class Circle {
        public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
    System.out.print("\033[31mEnter a number for radius: ");
    double radius = input.nextDouble();

    double area = radius * radius * 3.14159;

        System.out.println("\033[36mThe area for the circle of radius " +
            radius + " is " + area);
    }
}