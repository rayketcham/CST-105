/*
* Ray Ketcham
* October 9 2017
* CST-105
* Charles Lively
*/
package Week5;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
public class TwoDTwo {
public static void main(String[] args) {
    String filename = "C:\\School\\CST-105\\Week 5\\array.txt";
    //String filename = "C:\\School\\CST-105\\Week 5\\array1.txt";
    try
    {
    FileReader readConnectionToFile = new FileReader(filename);
    BufferedReader reads = new BufferedReader(readConnectionToFile);
    Scanner scan = new Scanner(reads);

    int[][] blah = new int[20][45];
    int counter = 0;
    {
        while(scan.hasNext() && counter < 1){
            for(int i = 0; i < 20; i++){
                counter = counter + 1;
                for(int m = 0; m < 45; m++){
                    blah[i][m] = scan.nextInt();
                }
            }
    }

            for(int i = 0; i < 20; i++){
            System.out.println("" + (i + 0)+
                    blah[i][0] +
                    blah[i][1] +
                    blah[i][2] +
                    blah[i][3] + 
                    blah[i][4] + 
                    blah[i][5] +
                    blah[i][6] + 
                    blah[i][7] + 
                    blah[i][8] + 
                    blah[i][9] + 
                    blah[i][10]+ 
                    blah[i][11] + 
                    blah[i][12] + 
                    blah[i][13] + 
                    blah[i][14] + 
                    blah[i][15] + 
                    blah[i][16] + 
                    blah[i][17] + 
                    blah[i][18] + 
                    blah[i][19]);

            }
    }   
    scan.close();
    } catch (FileNotFoundException y){
        System.out.println("Check the text file path" + filename);
    }
}     
}    
