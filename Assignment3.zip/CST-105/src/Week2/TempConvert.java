//  Ray Kecham
//  CST-105
//  September 25 2017
//  Charles Lively
//Converts input from C to F and F to C
package Week2;
import java.util.Scanner;
    public class TempConvert {
        public static void main(String[] Args) {
    
        Scanner cmd = new Scanner(System.in); 

// Convert Fahrenheit to Celsius 
        System.out.println("Enter Fahrenheit temperature :"); 
     
        double temperature = cmd.nextFloat(); 
        double celsius = toCelsius((float) temperature); 
        System.out.format("\033[31m%.0f\033[0m degrees Fahrenheit is \033[31m%.0f\033[0m degrees Celsius %n", temperature, celsius); 

// Convert Celsius to Fahrenheit 
        System.out.println("Enter Celsius temperature :"); 
        temperature = cmd.nextFloat(); 
        double fahrenheit = toFahrenheit((float) temperature); 
        System.out.format("\033[31m%.0f\033[0m degrees Celsius is \033[31m%.0f\033[0m degrees Fahrenheit %n", temperature, fahrenheit); 
    } 
// Convert Fahrenheit temperature to Celsius formula//
    public static double toCelsius(float fahrenheit) { 
    double celsius = (fahrenheit - 32) * 5 / 9; 
    return celsius; 
    }
// Convert temperature from Celsius to Fahrenheit fomula//
    public static float toFahrenheit
        (float celsius) { 
        float fahrenheit = 9 * (celsius / 5) + 32; 
        return fahrenheit; 
    }
}
