//  Ray Kecham
//  CST-105
//  September 25 2017
//  Charles Lively
//Java App will convert average five numbers input by user
package Week2;
import java.util.Scanner;
public class AvgOfFive {
    public static void main(String[] Args) {
        Scanner input = new  Scanner(System.in);
        System.out.print("Enter Five different numbers for a computational average: ");
        double number1 = input.nextDouble();
        double number2 = input.nextDouble();
        double number3 = input.nextDouble();
        double number4 = input.nextDouble();
        double number5 = input.nextDouble();    
    
        double average = (number1 + number2 + number3 + number4 + number5) /5;
        
        System.out.println("The average of " + number1 + " " + number2 + " " + number3 + " " + number4 + " " + number5 + " " + " is "+ average);
    }
}
